<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CapacityFiltersCheckboxes</name>
   <tag></tag>
   <elementGuidId>9a016a32-4739-4ad7-a6ce-6e4bf6e6af27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend[contains(text(),'Capacity')]]/div[contains(@class, 'uitk-layout-flex') and contains(@class, 'uitk-checkbox')]&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
