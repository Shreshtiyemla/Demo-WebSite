<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PricePerTraveller_element</name>
   <tag></tag>
   <elementGuidId>84b6f736-6085-4829-9a9c-c246b65f6459</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4[text()='Price per traveler']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
