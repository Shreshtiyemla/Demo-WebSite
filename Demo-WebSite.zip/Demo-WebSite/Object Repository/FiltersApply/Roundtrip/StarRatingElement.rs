<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>StarRatingElement</name>
   <tag></tag>
   <elementGuidId>3ca3cfa9-c5cd-48ea-97aa-bdcfe717bd21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4[@class='uitk-heading uitk-heading-7 uitk-spacing uitk-spacing-margin-blockend-two' and text()='Star rating']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
