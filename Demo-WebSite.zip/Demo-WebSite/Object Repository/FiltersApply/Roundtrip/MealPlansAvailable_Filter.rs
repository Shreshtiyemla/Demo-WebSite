<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MealPlansAvailable_Filter</name>
   <tag></tag>
   <elementGuidId>55cd8658-cd31-4c7d-bad0-95b07ac4b3c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[text()='Meal plans available']]//div[contains(@class,'uitk-layout-flex uitk-layout-flex-align-items-center uitk-layout-flex-gap-two')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
