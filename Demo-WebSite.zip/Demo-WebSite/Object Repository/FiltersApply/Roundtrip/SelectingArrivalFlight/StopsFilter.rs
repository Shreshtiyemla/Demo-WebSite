<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>StopsFilter</name>
   <tag></tag>
   <elementGuidId>7fff92f8-5102-46c2-baf0-5cdea36eab9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend[contains(text(),'Stops')]]//div[contains(@class, 'uitk-layout-flex uitk-layout-flex-align-items-center uitk-layout-flex-gap-two')]&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
