<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>StarRating_Filter</name>
   <tag></tag>
   <elementGuidId>9955a879-1877-4bab-bd05-4e4d8b598f53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[text()='Star rating']]//div[contains(@class,'uitk-button-toggle uitk-button-toggle-is-inline')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
