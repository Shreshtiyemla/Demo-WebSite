<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DepartureTimeInSource</name>
   <tag></tag>
   <elementGuidId>e75d023a-7dde-407c-a115-c7115cc1950d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[contains(text(), 'Departure time in Atlanta')]] //div[contains(@class, 'uitk-button-toggle') and contains(@class,'uitk-button-toggle-is-stacked')]&#xd;
&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
