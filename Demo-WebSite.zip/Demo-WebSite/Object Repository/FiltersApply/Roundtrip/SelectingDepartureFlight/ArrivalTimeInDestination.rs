<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ArrivalTimeInDestination</name>
   <tag></tag>
   <elementGuidId>83d914dc-14e6-4cdc-9bbb-10e8fc8d2dc7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[contains(text(), 'Arrival time in Atlanta')]] //div[contains(@class, 'uitk-button-toggle') and contains(@class, 'uitk-button-toggle-is-stacked')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
