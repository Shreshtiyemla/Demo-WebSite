<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MealPlansAvailable_Element</name>
   <tag></tag>
   <elementGuidId>355e8bde-7f7d-4d22-8c9e-1fa071c6ce75</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4[@class='uitk-heading uitk-heading-7' and text()='Meal plans available']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
