<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Amenities_Filter</name>
   <tag></tag>
   <elementGuidId>0552d212-61a4-4de9-8de9-3bc0ce48a4d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[text()='Amenities']]//div[contains(@class,'uitk-button-toggle uitk-button-toggle-is-stacked')]&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
