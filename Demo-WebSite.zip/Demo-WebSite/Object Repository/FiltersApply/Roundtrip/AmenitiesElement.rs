<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AmenitiesElement</name>
   <tag></tag>
   <elementGuidId>45766f37-66b1-43c7-9eab-6d2b5deadeaa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4[@class = 'uitk-heading uitk-heading-7 uitk-spacing uitk-spacing-margin-blockend-two' and text()='Amenities']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
