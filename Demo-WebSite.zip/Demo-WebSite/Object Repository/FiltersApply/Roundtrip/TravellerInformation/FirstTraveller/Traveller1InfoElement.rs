<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Traveller1InfoElement</name>
   <tag></tag>
   <elementGuidId>e533edea-ae5d-4d6b-841d-bef6c438deaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4[contains(text(), 'Traveler 1: Adult, primary contact')]&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
