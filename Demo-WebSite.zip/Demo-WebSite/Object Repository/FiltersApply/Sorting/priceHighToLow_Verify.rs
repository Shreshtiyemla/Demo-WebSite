<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>priceHighToLow_Verify</name>
   <tag></tag>
   <elementGuidId>95410f80-ffd5-4eeb-8e6f-93e000e3e8d2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
