<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Distance_from_DropDown_Verify</name>
   <tag></tag>
   <elementGuidId>4782c32c-39a5-4450-a295-b3272ef40f44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='uitk-text uitk-text-spacing-half truncate-lines-2 uitk-type-300 uitk-text-default-theme']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
