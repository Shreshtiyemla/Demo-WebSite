<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PopularLocations_Filter</name>
   <tag></tag>
   <elementGuidId>341ca8bc-4ef3-420a-bd64-5eb89afff220</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//fieldset[legend/h4[text()='Popular locations']]//div[contains(@class,'uitk-checkbox-content')]/label/p</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
