<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>JanuarySaleFilter_Data</name>
   <tag></tag>
   <elementGuidId>cf3a3ad6-6cfd-4fd3-9135-b2878fc77cfe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='uitk-card-content-section uitk-spacing uitk-spacing-padding-inline-three uitk-spacing-padding-blockstart-three uitk-spacing-padding-blockend-four']/child::section/h3</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
