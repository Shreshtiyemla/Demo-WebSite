<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>search_for_an_activity</name>
   <tag></tag>
   <elementGuidId>a14907e8-6af8-4f7b-bcc7-ac56dc410562</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[contains(@placeholder,'Enter a keyword')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
