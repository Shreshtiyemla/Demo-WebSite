<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>departing_button</name>
   <tag></tag>
   <elementGuidId>d4da5344-dbd2-40cb-a330-06a9122489ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@class='uitk-fake-input uitk-form-field-trigger uitk-field-fake-input uitk-field-fake-input-hasicon' and @name='EGDSDateRange-date-selector-trigger']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
