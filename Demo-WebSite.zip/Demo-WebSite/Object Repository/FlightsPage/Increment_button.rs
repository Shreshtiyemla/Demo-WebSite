<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Increment_button</name>
   <tag></tag>
   <elementGuidId>bac3cbfd-16be-41f5-a312-45c76d315b1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='uitk-layout-flex uitk-layout-flex-align-items-center uitk-layout-flex-justify-content-space-between uitk-step-input uitk-step-input-mounted']/child::div/button[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
