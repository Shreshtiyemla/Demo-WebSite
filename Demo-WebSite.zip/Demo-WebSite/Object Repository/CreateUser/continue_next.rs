<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>continue_next</name>
   <tag></tag>
   <elementGuidId>c77f9c30-1364-45c3-a0b7-28211813d203</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@class='uitk-link uitk-spacing uitk-spacing-padding-blockstart-twelve uitk-layout-flex-item uitk-link-align-left uitk-link-layout-default uitk-link-medium']&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
