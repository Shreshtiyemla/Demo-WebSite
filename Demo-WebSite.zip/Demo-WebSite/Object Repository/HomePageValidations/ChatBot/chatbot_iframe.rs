<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chatbot_iframe</name>
   <tag></tag>
   <elementGuidId>0d0d6dc3-44e5-4605-b709-f47003e6521d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[@aria-label='Chat with Virtual Agent ']&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/HomePageValidations/ChatBot/parentIframe</value>
      <webElementGuid>dd0eddc4-5406-48de-b276-35520eac1265</webElementGuid>
   </webElementProperties>
</WebElementEntity>
