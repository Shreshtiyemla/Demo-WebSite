<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>botClose_button</name>
   <tag></tag>
   <elementGuidId>0f71762b-c9a1-43b7-8917-101a5b90a175</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='vac-close-button']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/HomePageValidations/ChatBot/parentIframe</value>
      <webElementGuid>921ca22b-6a1c-46d3-ac4d-52d200cd2316</webElementGuid>
   </webElementProperties>
</WebElementEntity>
