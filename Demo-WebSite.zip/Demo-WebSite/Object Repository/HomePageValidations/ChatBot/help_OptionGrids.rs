<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>help_OptionGrids</name>
   <tag></tag>
   <elementGuidId>d738bfb0-6a9e-4d3a-b183-083f339e8d22</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='uitk-card uitk-card-roundcorner-all uitk-card-has-border uitk-card-has-link uitk-card-padded uitk-layout-flex-item uitk-layout-flex-item-max-width-third_width uitk-layout-flex-item-flex-basis-third_width uitk-layout-flex-item-flex-grow-1 uitk-card-has-primary-theme']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
