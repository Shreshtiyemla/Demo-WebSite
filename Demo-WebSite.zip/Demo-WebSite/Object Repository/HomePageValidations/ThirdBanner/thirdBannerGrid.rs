<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>thirdBannerGrid</name>
   <tag></tag>
   <elementGuidId>5886489f-37f2-41a9-bded-8206b7438901</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@style='--uitk-layoutgrid-auto-columns:minmax(var(--uitk-layoutgrid-egds-size__0x), 1fr);--uitk-layoutgrid-columns:repeat(3, minmax(0, 1fr))']/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
