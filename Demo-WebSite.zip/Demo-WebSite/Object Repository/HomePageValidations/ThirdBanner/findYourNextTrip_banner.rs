<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>findYourNextTrip_banner</name>
   <tag></tag>
   <elementGuidId>4c868689-1dd2-4694-864e-bf683fc829db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@href='/lp/b/guarantee?pwaLob=wizard-hotel-pwa-v2#editorial-3?rfrr=call-to-action.Find_your perfect trip.click']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
