<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lastMinute_button</name>
   <tag></tag>
   <elementGuidId>5e498274-9b02-4dbb-846f-b5a5c9084260</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@href='https://www.travelocity.com/lp/deals/last-minute' and @class='uitk-button uitk-button-medium uitk-button-has-text uitk-button-as-link uitk-button-secondary']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
