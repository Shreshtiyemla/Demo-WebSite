<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>bannerElement</name>
   <tag></tag>
   <elementGuidId>fff91373-3de4-4e4f-9888-0001d60c49f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='uitk-layout-flex uitk-layout-flex-flex-direction-column uitk-layout-flex-justify-content-center uitk-layout-position uitk-layout-position-top-center uitk-layout-position-absolute uitk-spacing uitk-spacing-padding-inline-twelve']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
