<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>sunnyBeachHotels_banner</name>
   <tag></tag>
   <elementGuidId>9060671c-23e7-4ce1-9eac-8c9db9be4e9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@href='https://www.travelocity.com/lp/deals/beach?rfrr=editorial.Sunny_beach hotel offers.click']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
