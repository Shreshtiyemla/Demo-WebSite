<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>sunnyBeachHotels_verify</name>
   <tag></tag>
   <elementGuidId>1ffd82c5-e589-4bba-8bf9-a95dc5f7f5d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[@class='uitk-heading uitk-heading-4' and contains(text(),'Seize your sun, sand, and surf savings')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
