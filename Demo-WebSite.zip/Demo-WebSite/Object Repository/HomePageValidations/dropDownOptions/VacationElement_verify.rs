<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>VacationElement_verify</name>
   <tag></tag>
   <elementGuidId>63697094-a856-49db-86a4-2e6493c74f8d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h1[@class='uitk-heading uitk-heading-2 uitk-spacing SimpleContainer cometHeading uitk-spacing-padding-small-blockend-three uitk-spacing-padding-small-blockstart-six uitk-spacing-padding-small-inline-six uitk-spacing-padding-medium-blockend-unset']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
