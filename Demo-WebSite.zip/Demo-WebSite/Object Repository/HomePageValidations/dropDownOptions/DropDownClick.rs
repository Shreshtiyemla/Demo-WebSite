<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DropDownClick</name>
   <tag></tag>
   <elementGuidId>5fd9eb8c-7608-4959-b64f-47b1eac0d558</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h3[@class='uitk-heading uitk-heading-5 uitk-layout-flex-item uitk-layout-flex-item-flex-grow-1']&#xd;
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
