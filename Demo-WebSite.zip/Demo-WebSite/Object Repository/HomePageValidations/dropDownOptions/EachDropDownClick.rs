<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EachDropDownClick</name>
   <tag></tag>
   <elementGuidId>80320bdc-43a8-46b8-a207-3a2c536c6d03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h3[@class='uitk-heading uitk-heading-5 uitk-layout-flex-item uitk-layout-flex-item-flex-grow-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
