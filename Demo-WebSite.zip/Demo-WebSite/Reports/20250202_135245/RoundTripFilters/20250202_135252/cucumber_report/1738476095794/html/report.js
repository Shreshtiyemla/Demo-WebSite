$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/FlightsPage.feature");
formatter.feature({
  "name": "Sign In and FlightsPage",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User comes to the website",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User opens browser",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_opens_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User Searches for Flights (RoundTrip) and applies Filters",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@RoundTripFilters"
    }
  ]
});
formatter.step({
  "name": "User comes to Flights Page and verifies the element",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_comes_to_flights_page_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects fixed source and destination",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_fixed_source_destination()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Departing and Returning dates",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_returning_dates()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects number of travellers",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_number_of_Travellers()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User clicks the checkBoxes and clicks search button",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_clicks_the_checkboxes()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User applies popular filters",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_popularFilters()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User applies Stays filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_stays_filter()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user applies Amenities filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_amenities_filter()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user applies price filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_price_filter()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User applies Star rating filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_starRating_filters()"
});
formatter.result({
  "status": "passed"
});
});