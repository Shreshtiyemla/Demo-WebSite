$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/FlightsPage.feature");
formatter.feature({
  "name": "Sign In and FlightsPage",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User comes to the website",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User opens browser",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_opens_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User Searches for Flights (RoundTrip) and books a flight",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@RoundTripBookingFlight"
    }
  ]
});
formatter.step({
  "name": "User comes to Flights Page and verifies the element",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_comes_to_flights_page_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects fixed source and destination",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_fixed_source_destination()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Departing and Returning dates",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_returning_dates()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user selects only travellers and clicks checkbooxes , searches the flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_only_travellers()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User applies Stays filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_stays_filter()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Filter Price High To Low and verifies",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_price_high_to_low_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Hotel and room",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_hotel_and_room()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user applies filters and selects departing flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_flight()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user applies filters and selects returning flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_returning_flight()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user applies filters and selects car",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_car()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user adds the main traveller information",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_traveller_information()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user adds the second traveller information",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_second_traveller()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user adds the insurance",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_insurance()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user adds the paymentInformation",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_paymentInformation()"
});
formatter.result({
  "status": "passed"
});
});