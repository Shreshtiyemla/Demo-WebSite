$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/FlightsPage.feature");
formatter.feature({
  "name": "Sign In and FlightsPage",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User comes to the website",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User opens browser",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_opens_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User Searches for Flights (RoundTrip) and books a flight",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@RoundTripBookingFlight"
    }
  ]
});
formatter.step({
  "name": "User comes to Flights Page and verifies the element",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_comes_to_flights_page_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects fixed source and destination",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_fixed_source_destination()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Departing and Returning dates",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_returning_dates()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user selects only travellers and clicks checkbooxes , searches the flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_only_travellers()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User applies Stays filter",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_applies_stays_filter()"
});
formatter.result({
  "error_message": "com.kms.katalon.core.exception.StepFailedException: Unable to scroll to object \u0027Object Repository/FiltersApply/Roundtrip/stayOptions\u0027\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.stepFailed(WebUIKeywordMain.groovy:117)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:43)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword.scrollToElement(ScrollToElementKeyword.groovy:88)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword.execute(ScrollToElementKeyword.groovy:68)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.scrollToElement(WebUiBuiltInKeywords.groovy:4184)\r\n\tat stepDefinations.FlightsPage.user_applies_stays_filter(FlightsPage.java:281)\r\n\tat ✽.User applies Stays filter(C:/Users/shres/git/Demo-WebSite/Include/features/FlightsPage.feature:78)\r\nCaused by: com.kms.katalon.core.webui.exception.WebElementNotFoundException: Web element with id: \u0027Object Repository/FiltersApply/Roundtrip/stayOptions\u0027 located by \u0027//h4[@class\u003d\u0027uitk-heading uitk-heading-7\u0027 and text()\u003d\u0027Stay options\u0027]\u0027 not found\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findWebElement(WebUiCommonHelper.java:1426)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword.findWebElement(WebUIAbstractKeyword.groovy:27)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword.findWebElement(WebUIAbstractKeyword.groovy:26)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword$_scrollToElement_closure1.doCall(ScrollToElementKeyword.groovy:79)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword$_scrollToElement_closure1.call(ScrollToElementKeyword.groovy)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:35)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword.scrollToElement(ScrollToElementKeyword.groovy:88)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ScrollToElementKeyword.execute(ScrollToElementKeyword.groovy:68)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.scrollToElement(WebUiBuiltInKeywords.groovy:4184)\r\n\tat stepDefinations.FlightsPage.user_applies_stays_filter(FlightsPage.java:281)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:26)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:20)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:48)\r\n\tat cucumber.runtime.PickleStepDefinitionMatch.runStep(PickleStepDefinitionMatch.java:50)\r\n\tat cucumber.runner.TestStep.executeStep(TestStep.java:72)\r\n\tat cucumber.runner.TestStep.run(TestStep.java:54)\r\n\tat cucumber.runner.PickleStepTestStep.run(PickleStepTestStep.java:53)\r\n\tat cucumber.runner.TestCase.run(TestCase.java:47)\r\n\tat cucumber.runner.Runner.runPickle(Runner.java:44)\r\n\tat cucumber.runtime.Runtime.runFeature(Runtime.java:120)\r\n\tat cucumber.runtime.Runtime.run(Runtime.java:106)\r\n\tat cucumber.api.cli.Main.run(Main.java:35)\r\n\tat cucumber.api.cli.Main$run.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFileWithTags_closure2.doCall(CucumberBuiltinKeywords.groovy:206)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFileWithTags_closure2.doCall(CucumberBuiltinKeywords.groovy)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:75)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:69)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain$runKeyword.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFileWithTags(CucumberBuiltinKeywords.groovy:166)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$runFeatureFileWithTags.callStatic(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFileWithTags(CucumberBuiltinKeywords.groovy:300)\r\n\tat BookingFlight.run(BookingFlight:22)\r\n\tat com.kms.katalon.core.main.ScriptEngine.run(ScriptEngine.java:194)\r\n\tat com.kms.katalon.core.main.ScriptEngine.runScriptAsRawText(ScriptEngine.java:119)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.runScript(TestCaseExecutor.java:448)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.doExecute(TestCaseExecutor.java:439)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.processExecutionPhase(TestCaseExecutor.java:418)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.accessMainPhase(TestCaseExecutor.java:410)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.execute(TestCaseExecutor.java:285)\r\n\tat com.kms.katalon.core.common.CommonExecutor.accessTestCaseMainPhase(CommonExecutor.java:65)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.accessTestSuiteMainPhase(TestSuiteExecutor.java:161)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.execute(TestSuiteExecutor.java:107)\r\n\tat com.kms.katalon.core.main.TestCaseMain.startTestSuite(TestCaseMain.java:176)\r\n\tat TempTestSuite1738475576701.run(TempTestSuite1738475576701.groovy:35)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\r\n\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "User selects Filter Price High To Low and verifies",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_price_high_to_low_verifies()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "User selects Hotel and room",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_hotel_and_room()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user applies filters and selects departing flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_flight()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user applies filters and selects returning flight",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_returning_flight()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user applies filters and selects car",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_car()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user adds the main traveller information",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_traveller_information()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user adds the second traveller information",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_second_traveller()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user adds the insurance",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_insurance()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "user adds the paymentInformation",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_adds_the_paymentInformation()"
});
formatter.result({
  "status": "skipped"
});
});