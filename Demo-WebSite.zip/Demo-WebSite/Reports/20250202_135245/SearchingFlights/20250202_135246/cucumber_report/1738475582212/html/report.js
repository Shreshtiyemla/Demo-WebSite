$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/FlightsPage.feature");
formatter.feature({
  "name": "Sign In and FlightsPage",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User comes to the website",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User opens browser",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_opens_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User Searches for Flights (RoundTrip)",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@Roundtrip"
    }
  ]
});
formatter.step({
  "name": "User comes to Flights Page and verifies the element",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_comes_to_flights_page_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects source and destination",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_source_destination()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects Departing and Returning dates",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_departing_returning_dates()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User selects number of travellers",
  "keyword": "When "
});
formatter.match({
  "location": "FlightsPage.user_selects_number_of_Travellers()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User clicks the checkBoxes and clicks search button",
  "keyword": "Then "
});
formatter.match({
  "location": "FlightsPage.user_clicks_the_checkboxes()"
});
formatter.result({
  "status": "passed"
});
});