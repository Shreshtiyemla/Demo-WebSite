$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/HomePageValidations.feature");
formatter.feature({
  "name": "FlightsPage Validations",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User navigates to HomePage",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User comes to the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "HomePageValidations.user_comes_to_home_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "HomePageValidations",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@HomePageValidations"
    }
  ]
});
formatter.step({
  "name": "User comes to Flights Page and verifies the element",
  "keyword": "Given "
});
formatter.match({
  "location": "FlightsPage.user_comes_to_flights_page_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to ThirdBanner,clicks and verifies the elements",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_scrolls_to_thirdBanner()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to Resorts,clicks and verifies the elements",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_scrolls_to_resorts()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to StartPlanningYourTrip,clicks and verifies the elements",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_scroll_to_startPlanningYourTrip_verifies()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to ChatBot,clicks and verifies the grids",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_scrolls_to_chatBot_verifies()"
});
formatter.result({
  "status": "passed"
});
});