$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/shres/git/Demo-WebSite/Include/features/HomePageValidations.feature");
formatter.feature({
  "name": "FlightsPage Validations",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "User navigates to HomePage",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "User comes to the home page",
  "keyword": "Given "
});
formatter.match({
  "location": "HomePageValidations.user_comes_to_home_page()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "HomePageValidations-DropDowns",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@DropDowns"
    }
  ]
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies Hotel DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_first_DropDown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies Flights DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_Flights_DropDown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies Vacation DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_Vacation_DropDown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies Cars DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_Cars_DropDown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies Cruises DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_Cruises_DropDown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Scrolls to DropDownOptions clicks and verifies TravelDeals DropDown",
  "keyword": "When "
});
formatter.match({
  "location": "HomePageValidations.user_Scrolls_To_DropDowns_verifies_TravelDeals_DropDown()"
});
formatter.result({
  "status": "passed"
});
});