package stepDefinations;
import internal.GlobalVariable;
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint;
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase;
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData;
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject;
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject;

import java.util.List;
import java.util.Random;

import com.kms.katalon.core.annotation.Keyword;
import com.kms.katalon.core.checkpoint.Checkpoint;
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords;
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords;
import com.kms.katalon.core.model.FailureHandling;
import com.kms.katalon.core.testcase.TestCase;
import com.kms.katalon.core.testdata.TestData;
import com.kms.katalon.core.testobject.TestObject;
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords;
import com.kms.katalon.core.webui.exception.WebElementNotFoundException;
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords;
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

import org.junit.Assert;
import stepDefinations.Utilities;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class ThingsToDo {
	@Given("User comes to ThingsToDo Page and verifies the element")
	public void user_comes_to_thingstodoPage_verifies_element() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/ThingsToDoPage/ThingsToDo_button"));
		WebUiBuiltInKeywords.maximizeWindow();
		boolean isThingsToDoPageAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/ThingsToDoPage/ThingsToDo_button"), 3);
		Assert.assertTrue("ThingsToDo button element is not visible.", isThingsToDoPageAvailable);
	    System.out.println("ThingsToDo Page element verified successfully.");
	}
	@When("User Selects the Destination")
	public void user_selects_destination() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/ThingsToDoPage/destination_click"));
		String destinationText = Utilities.generateRandomText();
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/ThingsToDoPage/destination_input"), destinationText);
		List<WebElement> destinationWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
		destinationWebOptions.get(0).click();
	}
	@When("User searches and applies filters")
	public void user_searches_and_applies_filters() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
	    WebUiBuiltInKeywords.delay(5);
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/ThingsToDoPage/SortSelect_click"), 2);
	    WebUiBuiltInKeywords.click(findTestObject("Object Repository/ThingsToDoPage/PriceLowToHigh_Click"));
	    WebUiBuiltInKeywords.delay(5);
	    List<WebElement> filterData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/ThingsToDoPage/JanuarySaleFilter_Data"), 2);
	    System.out.println("Price LowToHigh Data:");
	    for(WebElement element : filterData) {
	    	System.out.println(element.getText());
	    }
	    WebUiBuiltInKeywords.back();
	    List<WebElement> recommendationsFilter = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Recommendations_Filter"), 2);
        List<String> checkboxNames = List.of(
            "Free cancellation", 
            "Deals", 
            "Available today", 
            "Local expert picks",
            "Family friendly",
            "New on Travelocity",
            "Selective hotel pickup"
        );
        Utilities.selectRandomCheckbox(recommendationsFilter, checkboxNames);
        WebUiBuiltInKeywords.delay(2);
        List<WebElement> recommendationFilterData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/ThingsToDoPage/JanuarySaleFilter_Data"), 2);
	    System.out.println("RecommendationFilterData:");
	    for(WebElement element : recommendationFilterData) {
	    	System.out.println(element.getText());
	    }
	}
	
	
	@When("user search for an activity")
	public void user_search_for_an_activity() {
		WebUiBuiltInKeywords.click(findTestObject("ThingsToDoPage/search_for_an_activity"));
		WebUiBuiltInKeywords.setText(findTestObject("ThingsToDoPage/search_for_an_activity"), "Free");
		WebUiBuiltInKeywords.sendKeys(findTestObject("ThingsToDoPage/search_for_an_activity"), Keys.chord(Keys.ENTER));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}