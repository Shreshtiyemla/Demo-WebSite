package stepDefinations;
import internal.GlobalVariable;
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint;
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase;
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData;
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject;
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject;

import org.junit.Assert;
import org.openqa.selenium.StaleElementReferenceException;

import com.kms.katalon.core.annotation.Keyword;
import com.kms.katalon.core.checkpoint.Checkpoint;
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords;
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords;
import com.kms.katalon.core.model.FailureHandling;
import com.kms.katalon.core.testcase.TestCase;
import com.kms.katalon.core.testdata.TestData;
import com.kms.katalon.core.testobject.TestObject;
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords;
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords;
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateUserAndSignIn {
	@Given("User wants to open Browser")
	public void user_opens_the_browser() {
		WebUiBuiltInKeywords.openBrowser("");
	}
	@When("User navigates to signInPage and clicks create one button")
	public void user_tries_to_create_account() {
		WebUiBuiltInKeywords.navigateToUrl("https://www.travelocity.com/signup");
	}
//	@When("User enters email Address(.*)")
//	public void user_enters_email_Address(String emailAddress) {
//		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/EmailAddress"), emailAddress);
//	}
//	@When("User enters FirstName (.*) and enters LastName (.*)")
//	public void user_enters_firstName_lastName(String firstName, String lastName) {
//		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/first_Name"), firstName);
//		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/last_Name"), lastName);
//	}
//	@When("User enters password (.*)")
//	public void user_enters_password(String password) {
//		WebUiBuiltInKeywords.setEncryptedText(findTestObject("Object Repository/CreateUser/password"), password);
//	}
	@When("User clicks continue")
	public void user_clicks_continue() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/CreateUser/continue_button"));
	}
	@Then("User created account successfully")
	public void user_created_account() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/CreateUser/continue_next"));
	}
	
	/* SIGN IN USER */
	
	@Given("User Opens Browser and enters Credentials")
	public void user_navigates_to_signIn_page() {
		WebUiBuiltInKeywords.openBrowser(GlobalVariable.webSiteUrl.toString());
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/UserSignIn/userEmailAddress"), GlobalVariable.emailAddress.toString());
		WebUiBuiltInKeywords.setEncryptedText(findTestObject("Object Repository/UserSignIn/userPassword"),GlobalVariable.password.toString());
	}
	@When("User clicks SignIn button,SignIns and verifies HomePage")
	public void user_clicks_signIn() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/UserSignIn/userSignInButton"));
		WebUiBuiltInKeywords.delay(20);
		boolean hasUserComeToHomePage = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FlightsPage/HomePage_Verify"), 2);
		try {
	        Assert.assertTrue("Homepage is not visible after sign-in", hasUserComeToHomePage);
	        System.out.println("User successfully signed in and reached the homepage.");
	    } catch (StaleElementReferenceException e) {
	        System.err.println("Assertion failed: Homepage not found after sign-in.");
	    }
	}
}