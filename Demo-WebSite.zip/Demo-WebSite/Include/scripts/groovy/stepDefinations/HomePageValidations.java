package stepDefinations;
import internal.GlobalVariable;
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint;
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase;
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData;
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject;
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import com.kms.katalon.core.annotation.Keyword;
import com.kms.katalon.core.checkpoint.Checkpoint;
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords;
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords;
import com.kms.katalon.core.model.FailureHandling;
import com.kms.katalon.core.testcase.TestCase;
import com.kms.katalon.core.testdata.TestData;
import com.kms.katalon.core.testobject.TestObject;
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords;
import com.kms.katalon.core.webui.exception.WebElementNotFoundException;
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords;
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class HomePageValidations {
	@Given("User comes to the home page")
	public void user_comes_to_home_page() {
		
		WebUiBuiltInKeywords.openBrowser("");
		WebUiBuiltInKeywords.navigateToUrl("https://www.travelocity.com/");
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/FlightsPageButton"));
		
	}
	@When("User Scrolls to Explore Stays,clicks and verifies the elements")
	public void user_scrolls_to_explore_stays() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Explore Stays/ExploreStays_verify"), 5);
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/Explore Stays/ExploreStays_verify"), 2);
		System.out.println("Explore Stays Element Present");
		List<WebElement> exploreStaysBanners = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/Explore Stays/exploreStays_images"), 3);
		System.out.println(exploreStaysBanners.size());
		for(WebElement eachImage : exploreStaysBanners) {
			eachImage.click();
			WebUiBuiltInKeywords.switchToWindowIndex(1);
			WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/Explore Stays/exploreStaysIndividual"), 4);
			WebUiBuiltInKeywords.closeWindowIndex(1);
			WebUiBuiltInKeywords.switchToWindowIndex(0);
			WebUiBuiltInKeywords.delay(2);
		}
	}
	@When("User Scrolls to ExploreDeals , clicks and verifies the Discount")
	public void user_scrolls_to_explore_deals() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Explore Deals/bannerElement"), 2);
		boolean isExploreDealsBannerPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/Explore Deals/bannerElement_verify"), 2);
		if(isExploreDealsBannerPresent) {
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/HomePageValidations/Explore Deals/exploreDeals_button"));
			WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Explore Deals/exploreDealsHotels_list"), 2);
			
			List<WebElement> listOfHotels = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/Explore Deals/exploreDealsHotels_list"), 3);
			for(WebElement element : listOfHotels) 
			{
				System.out.println(element.getText());
				
				List<WebElement> originalPriceElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/Explore Deals/originalPrice"),3);
				String originalPriceText = originalPriceElements.get(0).getText();
				String originalPriceWithoutCurrency = originalPriceText.replace("$", "").trim();
				double originalPrice = Double.parseDouble(originalPriceWithoutCurrency);
				System.out.println(originalPrice);
				
				List<WebElement> discountPriceElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/Explore Deals/discountPrice"), 3);
				String discountPriceText = discountPriceElements.get(0).getText();
				String discountPriceWithoutCurrency = discountPriceText.replace("$", "").trim();
				double discountPrice = Double.parseDouble(discountPriceWithoutCurrency);
				System.out.println(discountPrice);
				
				double percentage = ((originalPrice-discountPrice)/originalPrice)*100;
				double roundedValue = Math.round(percentage * 100.0) / 100.0; 
				System.out.println(percentage);
				System.out.println(roundedValue);
				
				if(roundedValue>=25.0) 
				{
					System.out.println("Element Found with discount percentage greater than 25%");
				}
				else 
				{
					System.out.println("Element Not Found");
				}
				
			}
			WebUiBuiltInKeywords.back();
		}
		else 
		{
			System.out.println("Banner Not Found");
		}
	}
	@When("User Scrolls to ThirdBanner,clicks and verifies the elements")
	public void user_scrolls_to_thirdBanner() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/ThirdBanner/thirdBannerGrid"), 4);
		List<WebElement> bannerGrids = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/ThirdBanner/thirdBannerGrid"), 2);
		for(WebElement eachBanner : bannerGrids) 
		{
			eachBanner.click();
			WebUiBuiltInKeywords.switchToWindowIndex(1);
			boolean isBannerAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/ThirdBanner/thirdBanner_verify"), 4);
			if(isBannerAvailable) 
			{
				System.out.println("Element found");
				WebUiBuiltInKeywords.closeWindowIndex(1);
				WebUiBuiltInKeywords.switchToWindowIndex(0);
				WebUiBuiltInKeywords.delay(2);
			}
			else 
			{
				System.out.println("Banner Not Found");
			}
		}
	}
	@When("User Scrolls to Resorts,clicks and verifies the elements")
	public void user_scrolls_to_resorts() {
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Resorts/inclusiveResorts_button"), 3);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/HomePageValidations/Resorts/inclusiveResorts_button"));
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Resorts/InclusiveResorts_verify"), 2);
		boolean isResortAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/Resorts/InclusiveResorts_verify"), 2);
		
		if(isResortAvailable) 
		{
			WebUiBuiltInKeywords.back();
		}
		else 
		{
			System.out.println("Element Not Found");
		}
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Resorts/lastMinute_button"), 3);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/HomePageValidations/Resorts/lastMinute_button"));
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/Resorts/InclusiveResorts_verify"), 2);
		boolean isResortLastMinuteAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/Resorts/InclusiveResorts_verify"), 2);
		if(isResortLastMinuteAvailable) 
		{
			WebUiBuiltInKeywords.back();
		}
		else 
		{
			System.out.println("Element Not Found");
		}
	}
//	@When("User Scrolls to StartPlanningYourTrip,clicks and verifies the elements")
//	public void user_scroll_to_startPlanningYourTrip() throws WebElementNotFoundException{
//		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/headerElementForStart"), 2);
//		boolean isElementAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/headerElementForStart"), 2);
//		if(isElementAvailable) {
//			List<WebElement> listOfGrids = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/Start_ImageGrids"), 3);
//			for(WebElement eachGrid : listOfGrids) {
//				eachGrid.click();
//				WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/image_grids"), 2);
////				WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/image_grids"), 2);
//				WebElement firstGrid = WebUiBuiltInKeywords.findWebElements(
//		                findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/image_grids"), 2
//		            ).get(0);
//				boolean isFirstGridPresent = firstGrid != null;
//	            assertTrue("First grid is not present in the opened tab", isFirstGridPresent);
//				WebUiBuiltInKeywords.delay(2);
//				WebUiBuiltInKeywords.back();
//				WebUiBuiltInKeywords.delay(2);
//			}
//		}
//	}
	
	@When("User Scrolls to StartPlanningYourTrip,clicks and verifies the elements")
	public void user_scroll_to_startPlanningYourTrip_verifies() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/headerElementForStart"), 2);
		boolean isElementAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/headerElementForStart"), 2);
		if(isElementAvailable) 
		{
			List<WebElement> listOfGrids = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/Start_ImageGrids"), 3);
			listOfGrids.get(0).click();
			WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/image1_verify"), 2);
			WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/StartPlanningYourTrip/image1_verify"), 2);
			WebUiBuiltInKeywords.back();
		}
	}
	
	@When("User Scrolls to ChatBot,clicks and verifies the grids")
	public void user_scrolls_to_chatBot_verifies() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/ChatBot/helpHeaderElement"), 2);
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/ChatBot/helpHeaderElement"), 2);
		
		List<WebElement> helpOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/ChatBot/help_OptionGrids"), 2);
		helpOptions.get(0).click();
		
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/ChatBot/chatbot_iframe"), 2);
		WebUiBuiltInKeywords.switchToDefaultContent();
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/HomePageValidations/ChatBot/botClose_button"));
		helpOptions.get(2).click();
		
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/ChatBot/chatbot_iframe"), 2);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/HomePageValidations/ChatBot/botClose_button"));
	}
	
//	@When("User Scrolls to DropDownOptions,clicks and verifies each elements")
//	public void user_scrolls_to_dropDownOptions() throws WebElementNotFoundException{
//		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
//		System.out.println("User Scrolled to DropDownElement");
//		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
//		System.out.println("DropDownElementOption Verified");
//		List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
//	    for (int i = 0; i < dropDownElements.size(); i++) {
//	        WebElement eachDropDownElement = dropDownElements.get(i);
//	        try {
//	            eachDropDownElement.click();
//	            WebUiBuiltInKeywords.delay(3);
//	            List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
//	            eachDropDownElements.get(0).click();
//	            System.out.println("SingleElementClicked");
//	            WebUiBuiltInKeywords.back();
//	            System.out.println("Back to HomePage");
//	        } catch (StaleElementReferenceException e) {
//	            System.err.println("Stale element encountered. Refetching...");
//	        }
//	    }
//	}
	
	
	@When("User Scrolls to DropDownOptions clicks and verifies Hotel DropDown")
	public void user_Scrolls_To_DropDowns_verifies_first_DropDown() throws WebElementNotFoundException {
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(0).click();
	    System.out.println("Hotel DropDown Opened");
	    WebUiBuiltInKeywords.delay(3);
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("Hotel DropDown Options:");
	    for (WebElement hotelElement : eachDropDownElements) 
	    {
	        System.out.println(hotelElement.getText());
	    }
	    
	    eachDropDownElements.get(0).click();
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/HotelElement_Verify"), 2);
	    boolean isHotelElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/HotelElement_Verify"), 2);
	    WebUiBuiltInKeywords.back();
	}
	
	
	@When("User Scrolls to DropDownOptions clicks and verifies Flights DropDown")
	public void user_Scrolls_To_DropDowns_verifies_Flights_DropDown() throws WebElementNotFoundException {
		
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(1).click();
	    WebUiBuiltInKeywords.delay(3);
	    
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("Flight DropDown Options:");
	    for (WebElement FlightElement : eachDropDownElements) 
	    {
	        System.out.println(FlightElement.getText());
	    }
	    
	    eachDropDownElements.get(4).click();
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/FlightElement_verify"), 2);
	    boolean isFlightElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/FlightElement_verify"), 2);
	    System.out.println("FlightElementVerified");
	    WebUiBuiltInKeywords.back();
	}
	
	@When("User Scrolls to DropDownOptions clicks and verifies Vacation DropDown")
	public void user_Scrolls_To_DropDowns_verifies_Vacation_DropDown() throws WebElementNotFoundException {
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(2).click();
	    WebUiBuiltInKeywords.delay(3);
	    
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("Vacation DropDown Options:");
	    for (WebElement FlightElement : eachDropDownElements) 
	    {
	        System.out.println(FlightElement.getText());
	    }
	    
	    eachDropDownElements.get(2).click();
	    boolean isVacationElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/VacationElement_verify"), 2);
	    WebUiBuiltInKeywords.back();
	}
	
	
	@When("User Scrolls to DropDownOptions clicks and verifies Cars DropDown")
	public void user_Scrolls_To_DropDowns_verifies_Cars_DropDown() throws WebElementNotFoundException {
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(3).click();
	    
	    System.out.println("Cars DropDown Opened");
	    WebUiBuiltInKeywords.delay(3);
	    
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("Cars DropDown Options:");
	    
	    for (WebElement FlightElement : eachDropDownElements) 
	    {
	        System.out.println(FlightElement.getText());
	    }
	    
	    eachDropDownElements.get(2).click();
	    boolean isCarsElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/CarElement_Verify"), 2);
	    System.out.println("CarsElementVerified");
	    WebUiBuiltInKeywords.back();
	}
	
	
	@When("User Scrolls to DropDownOptions clicks and verifies Cruises DropDown")
	public void user_Scrolls_To_DropDowns_verifies_Cruises_DropDown() throws WebElementNotFoundException {
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(4).click();
	    
	    System.out.println("Cruises DropDown Opened");
	    WebUiBuiltInKeywords.delay(3);
	    
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("Cruises DropDown Options:");
	    for (WebElement FlightElement : eachDropDownElements) 
	    {
	        System.out.println(FlightElement.getText());
	    }
	    
	    eachDropDownElements.get(2).click();
	    boolean isCruisesElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/CarElement_Verify"), 2);
	    System.out.println("CruisesElementVerified");
	    WebUiBuiltInKeywords.back();
	}
	
	@When("User Scrolls to DropDownOptions clicks and verifies TravelDeals DropDown")
	public void user_Scrolls_To_DropDowns_verifies_TravelDeals_DropDown() throws WebElementNotFoundException {
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 3);
	    boolean isDestinationIdeasElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/destinationIdeasElement"), 2);
	    List<WebElement> dropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownClick"), 2);
	    dropDownElements.get(5).click();
	    
	    System.out.println("TravelDeals DropDown Opened");
	    WebUiBuiltInKeywords.delay(3);
	    List<WebElement> eachDropDownElements = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/HomePageValidations/dropDownOptions/EachDropDownElements"), 2);
	    System.out.println("TravelDeals DropDown Options:");
	    
	    for (WebElement FlightElement : eachDropDownElements) 
	    {
	        System.out.println(FlightElement.getText());
	    }
	    
	    eachDropDownElements.get(2).click();
	    WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/HomePageValidations/dropDownOptions/travelDealsElement_verify"), 2);
	    boolean isTravelDealsElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/HomePageValidations/dropDownOptions/travelDealsElement_verify"), 2);
	    System.out.println("TravelDealsElementVerified");
	    WebUiBuiltInKeywords.back();
	}
}