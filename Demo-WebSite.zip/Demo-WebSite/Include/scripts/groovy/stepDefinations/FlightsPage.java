package stepDefinations;
import internal.GlobalVariable;

import org.assertj.core.util.Arrays;
import org.junit.Assert;

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint;
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase;
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData;
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject;
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

import com.kms.katalon.core.annotation.Keyword;
import com.kms.katalon.core.checkpoint.Checkpoint;
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords;
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords;
import com.kms.katalon.core.model.FailureHandling;
import com.kms.katalon.core.testcase.TestCase;
import com.kms.katalon.core.testdata.TestData;
import com.kms.katalon.core.testobject.TestObject;
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords;
import com.kms.katalon.core.webui.driver.DriverFactory;
import com.kms.katalon.core.webui.exception.WebElementNotFoundException;
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords;
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import stepDefinations.Utilities;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FlightsPage {
	@Given("User opens browser")
	public void user_opens_browser() {
		WebUiBuiltInKeywords.openBrowser(GlobalVariable.Url.toString());
	}
	
	@Given("User comes to Flights Page and verifies the element")
	public void user_comes_to_flights_page_verifies() {
		
		WebUiBuiltInKeywords.maximizeWindow();
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/FlightsPageButton"));
		
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FlightsPage/FlightsPageVerify"), 2);
		System.out.println("User comes to FlightsPage");
	}
	
	@When("User selects source and destination")
	public void user_selects_source_destination() {
		try {
			 WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/LeavingFrom_button"));
			 
		     String sourceText = Utilities.generateRandomText();
		     WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/LeavingFrom_input"), sourceText);
		     List<WebElement> sourceWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
		     sourceWebOptions.get(0).click();
		     String sourceCountry = sourceWebOptions.get(0).getText();
		     System.out.println(sourceCountry);
		     
		     WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/GoingTo_button"));
			 String destinationText = Utilities.generateRandomText();
			 WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/GoingTo_input"), destinationText);
			 List<WebElement> destinationWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
			 
			 
			 if(sourceCountry.equals(destinationWebOptions.get(0).getText())) {
				 destinationWebOptions.get(1).click();
				 System.out.println("DestinationCountry:" +destinationWebOptions.get(1).getText());
			 }
			 
			 else 
			 {
				 destinationWebOptions.get(0).click();
			 }
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	
	@When("User selects Departing and Returning dates")
	public void user_selects_departing_returning_dates() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/departing_button"));
		WebUiBuiltInKeywords.delay(5);
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/previousDate_button"));
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/fromDateClick_button"));
		
		List<WebElement> calendarDays = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/SelectingDate/calendarDays"), 10);
		calendarDays.get(4).click();
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/applyDate_button"));
	}
	
	@When("User selects number of travellers")
	public void user_selects_number_of_Travellers() throws WebElementNotFoundException {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/travellerSelect_button"));
		
		List<WebElement> incrementButtons = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/Increment_button"), 2);
		incrementButtons.get(0).click();
		WebUiBuiltInKeywords.delay(2);
		incrementButtons.get(1).click();
		WebUiBuiltInKeywords.delay(2);
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/chlidAge_verify"));
		List<WebElement> childAgeDropDowns = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/childAgeDropdowns"), 3);
		
		Random random = new Random();
	    int randomIndex = random.nextInt(childAgeDropDowns.size());
	    WebElement selectedOption = childAgeDropDowns.get(randomIndex);
	    selectedOption.click();
	    
	    WebUiBuiltInKeywords.delay(5);
	    System.out.println("Randomly selected age: " + selectedOption.getText());
//	    WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
	}
	
	@When("User clicks the checkBoxes and clicks search button")
	public void user_clicks_the_checkboxes() throws WebElementNotFoundException{
		
		List<WebElement> checkBoxes = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/addStayCarCheckBoxes"), 3);
		
		for(WebElement eachCheckBox : checkBoxes) {
			eachCheckBox.click();
			WebUiBuiltInKeywords.delay(3);
		}
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
		WebUiBuiltInKeywords.delay(20);
	}
	
	
	@When("User selects fixed source and destination")
	public void user_selects_fixed_source_destination() {
		try {
			 WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/LeavingFrom_button"));
			 WebUiBuiltInKeywords.delay(3);
			 
		     String sourceText = "A";
		     WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/LeavingFrom_input"), sourceText);
		     List<WebElement> sourceWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
		     sourceWebOptions.get(0).click();
		     String sourceCountry = sourceWebOptions.get(0).getText();
		     System.out.println(sourceCountry);
		     
		     WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/GoingTo_button"));
		     WebUiBuiltInKeywords.delay(3);
			 String destinationText = "A";
			 WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/GoingTo_input"), destinationText);
			 List<WebElement> destinationWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
			 
			 if(sourceCountry.equals(destinationWebOptions.get(0).getText())) 
			 {
				 destinationWebOptions.get(1).click();
				 System.out.println("DestinationCountry:" +destinationWebOptions.get(1).getText());
			 }
			 else 
			 {
				 destinationWebOptions.get(0).click();
			 }
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	@When("user selects only travellers and clicks checkbooxes , searches the flight")
	public void user_selects_only_travellers() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/travellerSelect_button"));
		
		List<WebElement> incrementButtons = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/Increment_button"), 2);
		incrementButtons.get(0).click();
		WebUiBuiltInKeywords.delay(2);
		
		List<WebElement> checkBoxes = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/addStayCarCheckBoxes"), 3);
		for(WebElement eachCheckBox : checkBoxes) {
			eachCheckBox.click();
			WebUiBuiltInKeywords.delay(3);
		}
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
		WebUiBuiltInKeywords.delay(20);
	}

	
	@When("User applies popular filters")
	public void user_applies_popularFilters() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/PopularFilter_Element"), 2);
		WebUiBuiltInKeywords.delay(2);
		
		boolean isPopularFilterAvailable = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/PopularFilter_Element"), 2);
		if(isPopularFilterAvailable) 
		{
			System.out.println("Popular Filter Found");
			List<WebElement> popularFilters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/PopularFilters"), 2);
			String text = Utilities.selectRandomCheckBox(popularFilters);
			List<WebElement> filters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/AppliedFilters"), 2);
			for(WebElement filter : filters) {
				if(filter.getText().equals(text)) 
				{
					System.out.println("Popular filter verified");
					WebUiBuiltInKeywords.delay(2);
					WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/RemoveFilterButton"));
					WebUiBuiltInKeywords.delay(2);
				}
				else 
				{
					System.out.println("Not verified");
				}
			}
		}
		else 
		{
			System.out.println("Element Not Found");
		}
	}
	
	@When("User applies Star rating filter")
	public void user_applies_starRating_filters() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/StarRatingElement"), 2, FailureHandling.CONTINUE_ON_FAILURE);
		WebUiBuiltInKeywords.delay(2);
		
		boolean isStarRatingElement = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/StarRatingElement"), 2,FailureHandling.CONTINUE_ON_FAILURE);
		if(isStarRatingElement) 
		{
			System.out.println("StarRating Element Found");
			List<WebElement> starRatingFilters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/StarRating_Filter"), 2, FailureHandling.CONTINUE_ON_FAILURE);
			Utilities.selectRandomFilter(starRatingFilters);
			
			List<WebElement> starRatings = 	WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/starRating_Verify"), 2);
			String regex1 = "^\\d\\.\\d out of \\d(?:\\.\\d)?$";
		    for (WebElement element : starRatings) 
		    {
		        String text = element.getText().trim(); 
		        if (text.matches(regex1)) 
		        {
		            System.out.println("Valid star rating found: " + text);
					
		        } 
		        else 
		        {
		            System.out.println("Invalid star rating found: " + text);
		        }
		       
		    }	
		}
		else 
		{
			System.out.println("Element Not Found");
		}
	}
	
	
	@When("User applies Stays filter")
	public void user_applies_stays_filter() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/stayOptions"), 2);
		WebUiBuiltInKeywords.delay(2);
		
		boolean isStayOptionsElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/stayOptions"), 2);
		
		if(isStayOptionsElementPresent) {
			
			System.out.println("Stay Options Element Found");
			
			List<WebElement> stayOptionsFilter = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/stayoptionsFilter"), 2);
			
			System.out.println("stay");
			
			String text = Utilities.selectRandomCheckBox(stayOptionsFilter);
			
			WebDriver driver=DriverFactory.getWebDriver();
			Actions action=new Actions(driver);
			if(text.equals("Any")) {
				
				System.out.println("Any Option Got Clicked");
				((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)");
				
			}
			else {
				List<WebElement> filters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/AppliedFilters"),2);
				for(WebElement filter : filters) {
				
					if(filter.getText().equals(text)) {
						
						System.out.println("StayOption Filter verified");
						
						WebUiBuiltInKeywords.delay(3);
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)");
						
						WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/RemoveFilterButton"));
						WebUiBuiltInKeywords.delay(2);

					}
					else 
					{
						System.out.println("Not verified");
					}
				}
					
			}
			
		}
		else 
		{
			System.out.println("Stay Options Element Not Found");
		}
	
		
	}
	@When("user applies Amenities filter")
	public void user_applies_amenities_filter() {
		try {
			WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/AmenitiesElement"), 2);
			WebUiBuiltInKeywords.delay(2);
			
			boolean isAmenitiesElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/AmenitiesElement"), 2);
			
			if(isAmenitiesElementPresent) {
				
				System.out.println("Amenities Element Found");
				
				List<WebElement> amenitiesFilters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/Amenities_Filter"), 2);
				String text = Utilities.selectRandomCheckBox(amenitiesFilters);
				
				List<WebElement> filters = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/AppliedFilters"), 2);
				for(WebElement filter : filters) 
				{
					if(filter.getText().equals(text)) 
					{
						System.out.println("Amenities filter verified");
						WebUiBuiltInKeywords.delay(2);
						WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/RemoveFilterButton"));
						WebUiBuiltInKeywords.delay(2);
						
					}
					else 
					{
						System.out.println("Not verified");
					}
				}
			}
			else 
			{
				System.out.println("Amenities Filter Not Found");
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	@When("user applies price filter")
	public void user_applies_price_filter() {
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/PricePerTraveller_element"), 2);
		WebUiBuiltInKeywords.delay(2);
		
		WebUiBuiltInKeywords.dragAndDropByOffset(findTestObject("Object Repository/FiltersApply/Roundtrip/minimumPrice"), 50, 0);
		String minPrice = WebUiBuiltInKeywords.getText(findTestObject("Object Repository/FiltersApply/Roundtrip/MinimumPrice_Value"));
		System.out.println(minPrice);
		
		WebUiBuiltInKeywords.delay(2);
		
		WebUiBuiltInKeywords.dragAndDropByOffset(findTestObject("Object Repository/FiltersApply/Roundtrip/minimumPrice"), -50, 0);
		WebUiBuiltInKeywords.delay(2);
		
	
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/RemoveFilterButton"));
		WebUiBuiltInKeywords.delay(2);
	}
	
	
	@When("User selects Hotel and room")
	public void user_selects_hotel_and_room() throws WebElementNotFoundException{
		
		try 
		{
			List<WebElement> hotelStays = WebUiBuiltInKeywords.findWebElements(findTestObject("FiltersApply/Roundtrip/SelectingHotel/MainHeadingHotel"), 2);
			String text = hotelStays.get(1).getText();
			System.out.println(text);
			
			List<WebElement> listOfHotels = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingHotel/list_hotel_container"), 2);
			WebElement hotelElement = listOfHotels.get(2);
			hotelElement.click();
			WebUiBuiltInKeywords.delay(2);
			WebUiBuiltInKeywords.switchToWindowIndex(1);
			
			WebElement selectedHotel = WebUiBuiltInKeywords.findWebElement(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingHotel/HotelPageHeading"));
			String hotelName = selectedHotel.getText();
			System.out.println(hotelName);
			
			if(text.equals(hotelName)) 
			{
				System.out.println("The Hotel is Matched");
				WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingHotel/ChooseYourRoom"), 2);
				WebUiBuiltInKeywords.delay(3);
				
				boolean isChoosingRoomElementPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingHotel/ChooseYourRoom"), 2);
				if(isChoosingRoomElementPresent) 
				{
					WebUiBuiltInKeywords.delay(5);
					List<WebElement> rooms = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingHotel/RoomSelect_Button"), 2);
					
					WebDriver driver=DriverFactory.getWebDriver();
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,200)");
					WebUiBuiltInKeywords.delay(5);
					rooms.get(0).click();
					WebUiBuiltInKeywords.delay(5);
					
				}
				else 
				{
					System.out.println("No Rooms Available");
					WebUiBuiltInKeywords.back();
				}
			}
			else 
			{
				System.out.println("Selected hotel is not matched");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	@When("user applies filters and selects departing flight")
	public void user_selects_departing_flight() {
		try {
			List<WebElement> departureTimings = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/DepartureTimeInSource"), 2);
			departureTimings.get(0).click();
				
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/DepartingFlight_Click"));
			
			List<WebElement> selectButtons = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/select_button"), 2);
			selectButtons.get(0).click();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("user applies filters and selects returning flight")
	public void user_selects_returning_flight() {
		try {
			List<WebElement> stopCheckboxes = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingArrivalFlight/StopsFilter"), 2);
			Utilities.selectRandomCheckBox(stopCheckboxes);
			
			List<WebElement> arrivalTimings = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/ArrivalTimeInDestination"), 2);
			arrivalTimings.get(0).click();
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/DepartingFlight_Click"));

			List<WebElement> selectButtons = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingDepartureFlight/select_button"), 2);
			selectButtons.get(0).click();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@When("user applies filters and selects car")
	public void user_selects_car() {
		try 
		{
			WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingCar/CapacityFilter"), 2);
			boolean isCapacityFilterPresent = WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingCar/CapacityFilter"), 2);
			if(isCapacityFilterPresent) 
			{
				List<WebElement> capacitiesFilter = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingCar/CapacityFiltersCheckboxes"), 2);
				Utilities.selectRandomCheckBox(capacitiesFilter);
				
				List<WebElement> listOfCars = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/SelectingCar/selectCar"), 2);
				listOfCars.get(0).click();
				WebUiBuiltInKeywords.delay(20);
			}
			else 
			{
				System.out.println("Element Not Found");
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	@When("user adds the main traveller information")
	public void user_adds_the_traveller_information() {
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/Traveller1InfoElement"), 2);
		List<Map<String, String>> travellersList = Utilities.selectTravellers();
		try 
		{
			List<WebElement> nameFields = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/TravellerNames"), 2);
			nameFields.get(0).sendKeys(travellersList.get(0).get("Firstname"));
			
			List<WebElement> middleNames = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/middleName"), 2);
			middleNames.get(0).sendKeys(travellersList.get(0).get("Middlename"));
			
			nameFields.get(1).sendKeys(travellersList.get(0).get("Lastname"));
			
			List<WebElement> emailAndNumber = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/emailAndNumber"), 2);
			emailAndNumber.get(0).sendKeys(travellersList.get(0).get("Emailaddress"));
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/CountrySelect_Click"));
			List<WebElement> countriesList = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/CountryOptions"), 2);
			for(WebElement element : countriesList) {
				String countryCode = travellersList.get(0).get("Country_Territory_Code");
				if(element.getText().equals(countryCode)) {
					element.click();
				}
			}
			emailAndNumber.get(1).sendKeys(travellersList.get(0).get("Phone_number"));
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/gender"));
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/MonthOfBirth"));
			List<WebElement> months = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/MonthOfBirthOptions"), 2);
			for(WebElement monthElement : months) {
				String month = travellersList.get(0).get("Month of Birth");
				if(monthElement.getText().equals(month)) {
					monthElement.click();
				}
			}
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/DateOfBirth"));
			List<WebElement> dates = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/DateOfBirthOptions"), 2);
			for(WebElement dateElement : dates) {
				String date = travellersList.get(0).get("Date of Birth");
				if(dateElement.getText().equals(date)) {
					dateElement.click();
				}
			}
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/YearOfBirth"));
			List<WebElement> years = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/YearOfBirthOptions"), 2);
			for(WebElement yearElement : years) {
				String year = travellersList.get(0).get("Year of Birth");
				if(yearElement.getText().equals(year)) {
					yearElement.click();
				}
			}
			
		} catch (WebElementNotFoundException e) {
			e.printStackTrace();
		}
}
	
	@When("user adds the second traveller information")
	public void user_adds_second_traveller() {
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/SecondTraveller/Traveller2InfoElement"), 2);
		List<Map<String, String>> travellersList = Utilities.selectTravellers();
		try 
		{
			List<WebElement> nameFields = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/TravellerNames"), 2);
			nameFields.get(2).sendKeys(travellersList.get(1).get("Firstname"));
			
			List<WebElement> middleNames = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/middleName"), 2);
			middleNames.get(3).sendKeys(travellersList.get(1).get("Middlename"));
			
			nameFields.get(3).sendKeys(travellersList.get(1).get("Lastname"));
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/SecondTraveller/gender"));
			
			
			List<WebElement> dateData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/BirthInfo"), 2);
			List<List<WebElement>> dataOptions = new ArrayList<>();
			dataOptions.add(WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/SecondTraveller/MonthOfBirthOptions"),2));
			dataOptions.add(WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/SecondTraveller/DateOfBirthOptions"), 2));
			dataOptions.add(WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/SecondTraveller/YearOfBirthOptions"), 2));
			String[] fixedValues = {travellersList.get(1).get("Month of Birth"), travellersList.get(1).get("Date of Birth"),travellersList.get(1).get("Year of Birth")};
			for (int i = 3; i < dateData.size(); i++) {
			    WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/FirstTraveller/BirthInfo"));
			    List<WebElement> options = dataOptions.get(i - 3);
			    String expectedValue = fixedValues[i - 3]; 
			    for (WebElement option : options) {
			        if (option.getText().trim().equals(expectedValue)) {
			            option.click();  
			            break; 
			        }
			    }
			}

			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	@When("user adds the insurance")
	public void user_adds_the_insurance() {
		
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/Necessary/ClickYes"), 2);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/Necessary/ClickYes"));
		WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/Necessary/carInsurance"), 2);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/Necessary/carInsurance"));
	}
	
	@When("user adds the paymentInformation")
	public void user_adds_the_paymentInformation() {
		try {
			WebUiBuiltInKeywords.scrollToElement(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/PaymentElement"), 2);
			List<Map<String, String>> travellersList = Utilities.selectTravellers();
			
			String NameOnCard = travellersList.get(2).get("Name_on_Card");
			WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/NameOnCard"), NameOnCard);
			
			String cardNumber = travellersList.get(2).get("Debit_Credit_Card_Number");
			WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/CardNumber"), cardNumber);
			
			List<WebElement> expiryData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/ExpiryDate"), 2);
			List<List<WebElement>> expiryOptions = new ArrayList<>();
			expiryOptions.add(WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/ExpiryMonthOptions"), 2));
			expiryOptions.add(WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/ExpiryYearOptions"), 2));

			String[] fixedValues = {travellersList.get(2).get("Expiration_Month"), travellersList.get(2).get("Expiration_Year")};

			for (int i = 0; i < expiryData.size(); i++) {
			    expiryData.get(i).click();
			    for (WebElement option : expiryOptions.get(i)) {
			        if (option.getText().equals(fixedValues[i])) {
			            option.click();
			            break;
			        }
			    }
			}
			
			WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/securityCode"), travellersList.get(2).get("Security_Code_CVV"));
			WebUiBuiltInKeywords.delay(5);
			
			List<WebElement> countryTerritories = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/Country_Territory"), 2);
			countryTerritories.get(1).click();
			List<WebElement> countries = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/CountryOptions"), 2);

			for (int i = 232; i < countries.size(); i++) {
			    WebElement country = countries.get(i);
			    System.out.println("Processing country: " + country.getText());  
			    String fixedCountry = travellersList.get(2).get("Country_Territory");
			    if (country.getText().equals(fixedCountry)) {
			        country.click();
			        System.out.println("Country clicked: " + country.getText());
			        break; 
			    }
			}

			List<WebElement> billingAddress = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/BillingAddress"), 2);
			billingAddress.get(1).sendKeys(travellersList.get(2).get("Billing_Address_1"));
			
			List<WebElement> cities = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/city"), 2);
			cities.get(1).sendKeys(travellersList.get(2).get("City"));
			
			List<WebElement> stateButton = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/State"), 2);
			stateButton.get(1).click();
			List<WebElement> stateOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/StateOptions"), 2);

			for (int i = 63; i < stateOptions.size(); i++) {
			    WebElement stateElement = stateOptions.get(i);
			    String fixedState = travellersList.get(2).get("State");
			    if (stateElement.getText().equals(fixedState)) {
			        stateElement.click();
			        System.out.println("Selected State: " + fixedState); 
			        break; 
			    }
			}

			List<WebElement> zipCodes = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Roundtrip/TravellerInformation/PaymentInformation/ZipCode"), 2);
			zipCodes.get(1).sendKeys(travellersList.get(2).get("ZIP_Code"));
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	
	@When("User selects one-way mode")
	public void user_selects_oneway_mode() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/One-wayFlights/one-way_button"));
	}
	
	@When("User Selects date to travel")
	public void user_selects_date_oneway_mode() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/One-wayFlights/swap_button"));
		WebUiBuiltInKeywords.delay(3);
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/one-way_date_button"));
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/previousDate_button"));
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/one-way_date_input"));
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/applyDate_button"));
	}
	
	@When("User clicks addPlaceToStay checkbox and searches")
	public void user_clicks_addPlaceToStay_checkbox_search() {
		try {
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/addStayCarCheckBoxes"));
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/departing_button"));
			WebUiBuiltInKeywords.delay(5);
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/previousDate_button"));
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/fromDateClick_button"));
			
			List<WebElement> calendarDays = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/SelectingDate/calendarDays"), 10);
			calendarDays.get(4).click();
			
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/SelectingDate/applyDate_button"));
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
		    WebUiBuiltInKeywords.delay(20);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/* Sorting Filters for RoundTrip and One-way mode*/
	
	@When("User adds accomodation filter and searches")
	public void user_adds_accomodation_filter_searches() {
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Roundtrip/accomodation_click"));
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/One-wayFlights/search_buttonRecommendation"));
		WebUiBuiltInKeywords.delay(20);
		
	}
	
	@When("User selects Filter Price Low To High and verifies")
	public void user_selects_price_low_to_high_verifies() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/priceLowToHigh"));
		
		List<WebElement> priceData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/priceLowToHigh_Verify"), 3);
		String PriceText1 = priceData.get(0).getText();
		String price1WithoutCurrency = PriceText1.replace("$", "").replace(",", "").trim();
		double price1 = Double.parseDouble(price1WithoutCurrency);
		System.out.println(price1);
		
		String PriceText2 = priceData.get(1).getText();
		String price2WithoutCurrency = PriceText2.replace("$", "").replace(",", "").trim();
		double price2 = Double.parseDouble(price2WithoutCurrency);
		System.out.println(price2);
		
		if(price1<=price2) 
		{
			System.out.println("*****Prices from Low To High*****");
			
			for(WebElement price : priceData) 
			{
				System.out.println("Price: " +price.getText());
			}
			System.out.println("PriceLowToHigh Filter Verified");
		}
		else 
		{
			System.out.println("Filter Not Verified");
		}
	}
	
	
	@When("User selects Filter Price High To Low and verifies")
	public void user_selects_price_high_to_low_verifies() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/priceHighToLow"));
		
		List<WebElement> priceData = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/priceLowToHigh_Verify"), 3);
		String PriceText1 = priceData.get(0).getText();
		String price1WithoutCurrency = PriceText1.replace("$", "").replace(",", "").trim();
		double price1 = Double.parseDouble(price1WithoutCurrency);
		System.out.println(price1);
		
		String PriceText2 = priceData.get(1).getText();
		String price2WithoutCurrency = PriceText2.replace("$", "").replace(",", "").trim();
		double price2 = Double.parseDouble(price2WithoutCurrency);
		System.out.println(price2);
		
		if(price1>price2) 
		{
			System.out.println("*****Prices from High To Low*****");
			
			for(WebElement price : priceData) 
			{
				System.out.println("Price: " +price.getText());
			}
			System.out.println("PriceHighToLow Filter Verified");
		}
		else 
		{
			System.out.println("Filter Not Verified");
		}
	}
	
	@When("User selects Filter Distance from DownTown and verifies")
	public void user_selects_distance_from_downTown_verifies() {
		try {
			WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/Distance_from_downTown"));
			
			List<WebElement> distances = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/Distance_from_DropDown_Verify"), 2);
			
			for(WebElement eachDistance : distances) 
			{
				System.out.println(eachDistance.getText());
			}
			
			String firstDistance = distances.get(0).getText();
			int spaceIndex1 = firstDistance.indexOf(" ");
			String firstValue = firstDistance.substring(0, spaceIndex1);
			double firstDistanceValue = Double.parseDouble(firstValue);
			System.out.println("Value before the first space: " + firstValue);
			
			String secondDistance = distances.get(1).getText();
			int spaceIndex2 = secondDistance.indexOf(" ");
			String secondValue = secondDistance.substring(0, spaceIndex2);
			double secondDistanceValue = Double.parseDouble(secondValue);
			System.out.println("Value before the first space: " + secondValue);
			
			if(firstDistanceValue<secondDistanceValue) 
			{
				System.out.println("Distance between dropDown has verified");
			}
			else 
			{
				System.out.println("Not Found");
			}
		}
		
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	@When("User selects Filter Guest Rating and verifies")
	public void user_selects_guest_rating_verifies() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/GuestRating"));
		
		List<WebElement> guestRatings = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/GuestRating_Verify"), 2);
		
		String regex = "^\\d+(\\.\\d+)?$";
	    for (WebElement element : guestRatings) 
	    {
	        String text = element.getText().trim(); 
	        if (text.matches(regex)) 
	        {
	            System.out.println("Valid guest rating found: " + text);
	        } else 
	        {
	            System.out.println("Invalid guest rating found: " + text);
	        }
	    }
	}
	
	
	@When("User selects Filter Star Rating and verifies")
	public void user_selects_star_rating_verifies() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/StarRating"));
		
		List<WebElement> starRatings = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/starRating_Verify"), 2);
		String regex = "^\\d\\.\\d out of \\d\\.\\d$";
	    for (WebElement element : starRatings) 
	    {
	        String text = element.getText().trim(); 
	        if (text.matches(regex)) 
	        {
	            System.out.println("Valid star rating found: " + text);
	        } else 
	        {
	            System.out.println("Invalid star rating found: " + text);
	        }
	    }
	}
	
	
	@When("User selects Filter PercentageDiscount and verifies")
	public void user_selects_percentageDiscount_verifies() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FiltersApply/Sorting/Percentage_Discount"));
		List<WebElement> originalPriceList = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/OriginalPrice_Verify"), 2);
	    List<WebElement> discountPriceList = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FiltersApply/Sorting/DiscountPrice_Verify"), 2);
	    
	    if (originalPriceList.size() != discountPriceList.size()) 
	    {
	        throw new IllegalArgumentException("The size of originalPriceList and discountPriceList does not match!");
	    }
	    
	    String priceRegex = "^\\$\\d{1,3}(,\\d{3})*$";
	    for (int i = 0; i < originalPriceList.size(); i++) 
	    {
	        String originalPrice = originalPriceList.get(i).getText().trim();
	        String discountPrice = discountPriceList.get(i).getText().trim();
	        boolean isOriginalPriceValid = originalPrice.matches(priceRegex);
	        boolean isDiscountPriceValid = discountPrice.matches(priceRegex);
	        if (isOriginalPriceValid && isDiscountPriceValid) 
	        {
	            System.out.println("Both prices at index " + i + " are valid. Original: " + originalPrice + ", Discount: " + discountPrice);
	        } else 
	        {
	            System.out.println("Mismatch or invalid price at index " + i + ". Original: " + originalPrice + ", Discount: " + discountPrice);
	        }
	    }
	}
	
	/*Sorting filters for Roundtrip and one-way mode ends here */
	
	
	
	
	
	@When("User selects multi-city mode")
	public void user_selects_multi_city_mode() throws WebElementNotFoundException{
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/multi-city_button"));
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/travellerSelect_button"));
		List<WebElement> incrementButtons = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/Increment_button"), 2);
		incrementButtons.get(0).click();
		WebUiBuiltInKeywords.delay(2);
		incrementButtons.get(1).click();
		WebUiBuiltInKeywords.delay(2);
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/chlidAge_verify"));
		List<WebElement> childAgeDropDowns = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/childAgeDropdowns"), 3);
		Random random = new Random();
	    int randomIndex = random.nextInt(childAgeDropDowns.size());
	    WebElement selectedOption = childAgeDropDowns.get(randomIndex);
	    selectedOption.click();
	    WebUiBuiltInKeywords.delay(2);
	    WebUiBuiltInKeywords.switchToDefaultContent();
	    System.out.println("Randomly selected age: " + selectedOption.getText());
	    WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/travellerSelect_button"));
	}
	
	@When("User selects Flight1 and verifies")
	public void user_selects_flight1_verifies() {
		
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/Flight1_element"), 2);
		System.out.println("Flight1 element found");
	}
	
	@When("User selects Flight2 and verifes")
	public void user_selects_flight2_verifies() {
		
		WebUiBuiltInKeywords.verifyElementPresent(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/Flight2_element"), 2);
		System.out.println("Flight2 element found");
	}
	
	@When("User Searches for the Flights and adds another flight")
	public void user_searches_for_flights() throws WebElementNotFoundException{
		
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/addAnotherFlight"));
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/LeavingFrom_button"));
		
	    String sourceText = Utilities.generateRandomText();
	    WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/LeavingFrom_input"), sourceText);
	    List<WebElement> sourceWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
	    sourceWebOptions.get(0).click();
	    String sourceCountry = sourceWebOptions.get(0).getText();
	    System.out.println(sourceCountry);
	    
	    WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/GoingTo_button"));
		String destinationText = Utilities.generateRandomText();
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/FlightsPage/GoingTo_input"), destinationText);
		
		List<WebElement> destinationWebOptions = WebUiBuiltInKeywords.findWebElements(findTestObject("Object Repository/FlightsPage/source_dropDowns"), 2);
		if(sourceCountry.equals(destinationWebOptions.get(0).getText())) 
		{
			destinationWebOptions.get(1).click();
			System.out.println("DestinationCountry:" +destinationWebOptions.get(1).getText());
		}
		else 
		{
			destinationWebOptions.get(0).click();
		}
	}
	
	@Then("User clicks Search button and removes one flight")
	public void user_clicks_search_button_removes_flight() {
		 WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/search_button"));
		 
		 WebUiBuiltInKeywords.click(findTestObject("Object Repository/FlightsPage/Multi-cityFlights/removeFlight"));
		 
	}
	
	
	
	
	
	
	
	
	
}