package stepDefinations;
import internal.GlobalVariable;
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint;
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase;
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData;
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject;
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject;

import com.kms.katalon.core.annotation.Keyword;
import com.kms.katalon.core.checkpoint.Checkpoint;
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords;
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords;
import com.kms.katalon.core.model.FailureHandling;
import com.kms.katalon.core.testcase.TestCase;
import com.kms.katalon.core.testdata.TestData;
import com.kms.katalon.core.testobject.TestObject;
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords;
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords;
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import groovy.json.JsonSlurper;

import java.io.File;
import java.nio.file.Paths;
import java.util.Map;

public class JsonData {
	
	private Map<String, String> userData;
	

	@Before
    public void readJsonData() {
        try {
        	String filePath = "C:/Users/shres/git/Demo-WebSite/data.json";
            File jsonFile = new File(filePath);
            if (jsonFile.exists()) {
                JsonSlurper jsonSlurper = new JsonSlurper();
                userData = (Map<String, String>) jsonSlurper.parse(jsonFile);


            } else {
                System.out.println("JSON file not found at: " + filePath);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@Given("User opens the browser and navigates to signInPage and clicks createone button")
	public void user_wants_to_open_Browser() {
		WebUiBuiltInKeywords.openBrowser("");
		WebUiBuiltInKeywords.navigateToUrl("https://www.travelocity.com/signup");
	}
	@When("User enters emailAddress")
	public void user_enters_emailAddress() {
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/EmailAddress"), userData.get("emailAddress"));
	}
	@When("User enters FirstName and LastName")
	public void user_enters_firstName_LastName() {
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/first_Name"), userData.get("firstName"));
		WebUiBuiltInKeywords.setText(findTestObject("Object Repository/CreateUser/last_Name"), userData.get("lastName"));
	}
	@When("User enters Password")
	public void user_enters_password() {
		WebUiBuiltInKeywords.setEncryptedText(findTestObject("Object Repository/CreateUser/password"), userData.get("password"));
	}
	@When("User clicks continue and logs in Successfully.")
	public void user_logs_in() {
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/CreateUser/continue_button"));
		WebUiBuiltInKeywords.click(findTestObject("Object Repository/CreateUser/continue_next"));
	}
	
	
	
	
	
	
	
}